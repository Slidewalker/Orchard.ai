<?php

// Minimal Alpha-01 Backend Handler (Server.php)
// This file handles internal 8000 port requests before Laravel is fully bootstrapped for Alpha-01.

$uri = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

// Mock API Route: /api/winnowing/stream
if ($uri === '/api/winnowing/stream') {
    require_once __DIR__ . '/app/Services/BedrockScoringAgent.php';
    $agent = new \App\Services\BedrockScoringAgent();
    
    $sampleTexts = [
        "Q4 sales up 22% due to new pricing strategy. Actionable insight.",
        "Just had coffee ☕",
        "Patient ID 4432 has hypertension",
        "Breaking: Orchard.ai winnowing hits 97% this hour",
        "Just finished sprint planning. Wheat: 3 new features."
    ];
    
    $posts = [];
    foreach ($sampleTexts as $text) {
        $scoreData = $agent->score($text);
        $score = round($scoreData['total_score'], 2);
        $verdict = $score > 0.7 ? 'wheat' : 'chaff';
        
        $posts[] = [
            'text' => $text,
            'utility' => round($scoreData['utility'], 2),
            'privacy' => round($scoreData['privacy'], 2),
            'co2' => round($scoreData['sustainability'], 2),
            'score' => $score,
            'verdict' => $verdict
        ];
    }
    
    header('Content-Type: application/json');
    echo json_encode(['posts' => $posts]);
    exit;
}

// Route: /api/winnowing/dispatch
// Dispatches a winnowing task to RabbitMQ for asynchronous processing by the Python workers.
if ($uri === '/api/winnowing/dispatch') {
    $content = $_GET['content'] ?? 'Project Orchard Alpha 01 Launch';
    
    // RabbitMQ Management API credentials (guest:guest is default)
    $ch = curl_init('http://rabbitmq:15672/api/exchanges/%2f/amq.default/publish');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERPWD, "guest:guest");
    curl_setopt($ch, CURLOPT_POST, true);
    
    $payload = json_encode([
        "routing_key" => "orchard_fanout",
        "properties" => (object)[],
        "payload" => json_encode(["text" => $content]),
        "payload_encoding" => "string"
    ]);
    
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    header('Content-Type: application/json');
    if ($httpCode === 200) {
        echo json_encode(['status' => 'success', 'message' => 'Winnowing task dispatched for: ' . $content]);
    } else {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Failed to dispatch task', 'rabbitmq_response' => json_decode($response)]);
    }
    exit;
}

// Route: /api/ai/chat
// Provides a chat response from the Orchard.ai Server Assistant.
if ($uri === '/api/ai/chat') {
    $input = json_decode(file_get_contents('php://input'), true);
    $message = $input['message'] ?? '';
    
    // Orchard.ai AI Personality / Response Logic
    $responses = [
        "Your request is being winnowed for compliance. How can I assist with your 90-day sprint?",
        "Shard health is optimal. The digital sieve is currently operating at 96% accuracy.",
        "Remember: Matthew 3:12. We must separate the wheat from the chaff to ensure system resilience.",
        "ISO 9001:2015 Clause 6.1 requires we address this risk immediately. Mitigation is recommended.",
        "Your query has been logged in the AI Sieve. Privacy and Sustainability scores are within acceptable thresholds."
    ];
    
    $reply = $responses[array_rand($responses)];
    
    // Simple mock logic for specific keywords
    if (stripos($message, 'status') !== false) $reply = "System status: All Bedrock workers active. Latency at 78ms.";
    if (stripos($message, 'hi') !== false || stripos($message, 'hello') !== false) $reply = "Greetings. I am the Orchard.ai Assistant. My purpose is resilience and winnowing.";
    
    header('Content-Type: application/json');
    echo json_encode(['reply' => $reply]);
    exit;
}

// Route: /api/compliance/mitigate
// Logs risk mitigation actions for ISO 9001 auditability.
if ($uri === '/api/compliance/mitigate') {
    $input = json_decode(file_get_contents('php://input'), true);
    $riskId = $input['riskId'] ?? 'unknown';
    $strategy = $input['strategy'] ?? 'none';
    
    // Log the mitigation action (Server-side logging)
    $logEntry = [
        'timestamp' => date('Y-m-d H:i:s'),
        'event' => 'RISK_MITIGATION_APPLIED',
        'risk_id' => $riskId,
        'strategy' => $strategy,
        'status' => 'ACCEPTED'
    ];
    
    // For Alpha-01, we output this to a persistent compliance log file
    file_put_contents(__DIR__ . '/compliance_audit.log', json_encode($logEntry) . PHP_EOL, FILE_APPEND);
    
    header('Content-Type: application/json');
    echo json_encode(['status' => 'success', 'message' => "Mitigation for Risk #$riskId officially logged.", 'audit_id' => uniqid()]);
    exit;
}

// Route: /api/storage/files
// Lists all files in the storage directory.
if ($uri === '/api/storage/files') {
    $storageDir = __DIR__ . '/storage';
    $files = [];
    if (is_dir($storageDir)) {
        $items = array_diff(scandir($storageDir), ['.', '..']);
        foreach ($items as $item) {
            $files[] = [
                'name' => $item,
                'size' => filesize($storageDir . '/' . $item),
                'type' => pathinfo($item, PATHINFO_EXTENSION)
            ];
        }
    }
    header('Content-Type: application/json');
    echo json_encode(['files' => $files]);
    exit;
}

// Route: /api/storage/upload
// Handles multi-part file uploads to the storage directory.
if ($uri === '/api/storage/upload' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $storageDir = __DIR__ . '/storage';
    if (!isset($_FILES['file'])) {
        http_response_code(400);
        echo json_encode(['error' => 'No file uploaded']);
        exit;
    }

    $file = $_FILES['file'];
    $name = basename($file['name']);
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $allowed = ['md', 'pdf', 'zip', 'docx', 'sql', 'txt'];

    if (!in_array($ext, $allowed)) {
        http_response_code(400);
        echo json_encode(['error' => 'Unsupported file type: ' . $ext]);
        exit;
    }

    if (move_uploaded_file($file['tmp_name'], $storageDir . '/' . $name)) {
        header('Content-Type: application/json');
        echo json_encode(['status' => 'success', 'name' => $name]);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to move uploaded file']);
    }
    exit;
}

// Route: /api/storage/delete
// Deletes a specific file from the storage directory.
if ($uri === '/api/storage/delete') {
    $name = $_GET['name'] ?? '';
    $storageDir = __DIR__ . '/storage';
    $filePath = $storageDir . '/' . basename($name);

    if ($name && file_exists($filePath)) {
        unlink($filePath);
        header('Content-Type: application/json');
        echo json_encode(['status' => 'success', 'message' => "File $name deleted."]);
    } else {
        http_response_code(404);
        echo json_encode(['error' => 'File not found']);
    }
    exit;
}

// Route: /api/lessons/list
// Returns the list of lessons learned from the persistent JSON store.
if ($uri === '/api/lessons/list') {
    $file = __DIR__ . '/lessons_learned.json';
    $lessons = [];
    if (file_exists($file)) {
        $lessons = json_decode(file_get_contents($file), true) ?: [];
    }
    header('Content-Type: application/json');
    echo json_encode(['lessons' => $lessons]);
    exit;
}

// Route: /api/lessons/log
// Persists a new lesson learned to the JSON store.
if ($uri === '/api/lessons/log' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $text = $input['lesson'] ?? '';
    
    if (!$text) {
        http_response_code(400);
        echo json_encode(['error' => 'Lesson text is required']);
        exit;
    }

    $file = __DIR__ . '/lessons_learned.json';
    $lessons = [];
    if (file_exists($file)) {
        $lessons = json_decode(file_get_contents($file), true) ?: [];
    }
    
    $newEntry = [
        'text' => $text,
        'timestamp' => date('Y-m-d H:i:s')
    ];
    array_unshift($lessons, $newEntry); // Newest first
    
    file_put_contents($file, json_encode($lessons, JSON_PRETTY_PRINT));
    
    header('Content-Type: application/json');
    echo json_encode(['status' => 'success', 'lesson' => $newEntry]);
    exit;
}

// Fallback: 404
http_response_code(404);
echo json_encode(['error' => 'Orchard.ai Alpha-01: Resource not found at ' . $uri]);
