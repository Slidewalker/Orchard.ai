import pika
import json
import sys
import os
import mysql.connector
import time

# Database configuration from environment variables
DB_CONFIG = {
    'host': os.environ.get('DB_HOST', 'db'),
    'user': os.environ.get('DB_USER', 'orchard_user'),
    'password': os.environ.get('DB_PASSWORD', 'orchard_pass'),
    'database': os.environ.get('DB_DATABASE', 'orchard_ai'),
}

def get_db_connection():
    conn = None
    while not conn:
        try:
            conn = mysql.connector.connect(**DB_CONFIG)
            print("Successfully connected to the database.")
        except mysql.connector.Error as err:
            print(f"Database connection failed: {err}. Retrying in 2 seconds...")
            time.sleep(2)
    return conn

def simulate_ai_winnowing(text):
    """
    Simulates AI scoring for Utility and Privacy.
    Returns a 'health_score' (0-100).
    """
    # Simple simulation: Length-based scoring as a placeholder
    score = min(100, len(text) * 2) 
    print(f" [AI] Winnowing content: '{text}' -> Score: {score}")
    return score

def callback(ch, method, properties, body):
    data = json.loads(body)
    text = data.get('text', 'Unknown Fruit')
    print(f" [x] Received: {text}")

    # Process: AI Winnowing
    health_score = simulate_ai_winnowing(text)
    score_decimal = health_score / 100.0
    verdict = 'wheat' if health_score > 50 else 'chaff'

    # Persistence: Save BOTH Wheat and Chaff for auditability (ISO 9001 Clause 7.5)
    try:
        db = get_db_connection()
        cursor = db.cursor()
        
        # New Schema Insertion
        sql = "INSERT INTO trees (name, content, score, verdict, shard_id) VALUES (%s, %s, %s, %s, %s)"
        # truncating name for the 'name' column, full text in 'content'
        display_name = (text[:47] + '..') if len(text) > 50 else text
        
        cursor.execute(sql, (display_name, text, score_decimal, verdict, 1))
        db.commit()
        
        status = "Preserved WHEAT" if verdict == 'wheat' else "Logged CHAFF (Pending 24h Purge)"
        print(f" [x] {status} in Database: {text}")
        
        cursor.close()
        db.close()
    except mysql.connector.Error as err:
        print(f" [!] Database Error: {err}")

def start_consumer():
    connection = None
    while not connection:
        try:
            connection = pika.BlockingConnection(pika.ConnectionParameters(host='rabbitmq'))
        except pika.exceptions.AMQPConnectionError:
            print("RabbitMQ not ready yet, retrying in 2 seconds...")
            time.sleep(2)

    channel = connection.channel()
    channel.queue_declare(queue='orchard_fanout')
    channel.basic_consume(queue='orchard_fanout', on_message_callback=callback, auto_ack=True)

    print(' [*] Waiting for messages. To exit press CTRL+C')
    channel.start_consuming()

if __name__ == '__main__':
    try:
        start_consumer()
    except KeyboardInterrupt:
        sys.exit(0)
